package com.example.adventuregame;

public class Player extends GameCharacter{

    public int TotalGold;

}
