package com.example.adventuregame;

public class Room {

    public boolean IsBlocked;

    public int gold;

    public GameCharacter monster;

  public NPC npc;

}
