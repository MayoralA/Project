package com.example.adventuregame;

public class GameCharacter {

    public int HitPoint;

    public int Strength;

    public int Dexterity;

    public int Intelligence;
}
